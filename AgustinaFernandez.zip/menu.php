<ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active text-dark" href="index.php" aria-current="page">Cargar Personaje</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-dark" href="verpersonajes.php">Ver Personaje</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-dark" href="comentform.php">Dejar Comentarios</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-dark" href="inforesult.php">Resultados de Comentarios</a>
  </li>
</ul>