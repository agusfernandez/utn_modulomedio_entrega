<?php 

//$conexion_db = mysqli_connect('localhost' , 'root' , 'root', 'entregas')  or exit ('No se pudo hacer la conexion de forma correcta');

$conexion_db = mysqli_connect('localhost' , 'id20486541_agustinafernandez' , 'v$1p1q=02RVRU~)P', 'id20486541_entregatres')  or exit ('No se pudo hacer la conexion de forma correcta');